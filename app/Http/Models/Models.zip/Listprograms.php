<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Listprograms extends Model
{
    protected $table = "programlist";
	
	/**
     * get programlist data order by session date
     * @Param : no
     * @Return : 9 program data list
     */
	
}
